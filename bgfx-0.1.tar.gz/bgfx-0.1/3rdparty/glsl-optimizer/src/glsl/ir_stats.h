#include "ir.h"

void calculate_shader_stats(exec_list* instructions, int* outMath, int* outTex, int* outFlow);
