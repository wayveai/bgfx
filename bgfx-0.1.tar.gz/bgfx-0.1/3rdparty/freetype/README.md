The Freetype code is copyright 2013 The FreeType Project.
All rights reserved. (www.freetype.org).
Distributed under the FreeType License: see FTL.TXT.

freetype.h is an amalagmation of Freetype 2.4.11 made by Jeremie Roy in march 2013.